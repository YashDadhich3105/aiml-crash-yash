# AIML Crash Course – Python, Pandas & NumPy Practice Repository

## Overview

This repository contains my hands-on Python programming practice, mini-projects, and data analysis exercises completed as part of my Artificial Intelligence and Machine Learning learning journey.

The repository covers Python fundamentals, Object-Oriented Programming (OOP), file handling, JSON processing, Pandas data analysis, and NumPy numerical computing. These projects have helped me strengthen my programming skills and build a solid foundation for Data Science, Machine Learning, and Software Development.

---

## Technologies Used

* Python 3.x
* Pandas
* NumPy
* JSON
* CSV
* Jupyter Notebook
* Git & GitHub

---

## Skills Demonstrated

* Python Fundamentals
* Functions and Modular Programming
* Object-Oriented Programming (OOP)
* File Handling
* JSON Processing
* CSV Data Management
* Data Analysis using Pandas
* Numerical Computing using NumPy
* Data Cleaning and Filtering
* Problem Solving
* Git & GitHub Version Control

---

## Files Included

# Day 1 – Python Fundamentals & Mini Projects

1. intro.ipynb – Student introduction using dictionaries and f-strings.

2. skills_counter.ipynb – Displays and counts skills using loops and formatting.

3. even_odd.ipynb – Checks whether a number is even or odd.

4. tip_calculator.ipynb – Calculates tip amount and total bill.

5. word_frequency.ipynb – Counts word frequency in a sentence.

6. calculator.ipynb – Basic calculator implementation using functions.

7. grade_classifier.ipynb – Classifies grades based on marks.

8. guessing_game.ipynb – Interactive number guessing game.

9. contact_book.ipynb – Contact management and search application.

---

# Day 2 – Intermediate Python Projects

10. student_report.py – Student report card system with average calculation and grade generation.

11. comprehension_drills.py – Exercises using list, dictionary, and set comprehensions.

12. file_records.py – Student record management using CSV files.

13. typed_calculator.py – Calculator implementation using type hints.

14. library_system.py – Library management system demonstrating inheritance and method overriding.

15. config_manager.py – JSON configuration manager for saving and loading settings.

16. fraction_class.py – Custom Fraction class with arithmetic operations.

17. inventory.py – Inventory management system with CSV integration.

---

# Day 7 – Python Intermediate + Pandas & NumPy Tasks

### Pandas & Data Analysis

18. pandas_explore.py – DataFrame creation, filtering, and analysis using Pandas.

19. task4_filter_dataframe.py – Selects specific columns and filters rows based on conditions.

20. task5_loc_iloc.py – Demonstrates label-based and position-based indexing.

21. task6_missing_values.py – Handles missing values using dropna() and fillna().

22. task7_insights.py – Generates insights using describe() and value_counts().

### NumPy Practice

23. task8_numpy_basics.py – Array creation, inspection, indexing, and slicing.

24. task9_numpy_advanced.py – Demonstrates masking, broadcasting, and cosine similarity.

### Python Intermediate + JSON

25. task1_profile_card.py – Creates a student profile card using dictionaries, type hints, and f-strings.

26. task2_json_report.py – Reads JSON data and generates a formatted learner report.

27. task3_class.py – Demonstrates Object-Oriented Programming using a Learner class.

28. data.json – Sample JSON dataset containing learner information and skills.

---

# Dataset & Configuration Files

29. students.csv – Sample student dataset used for practice.

30. results.csv – Generated report dataset.

31. inventory.csv – Inventory dataset for inventory management.

32. config.json – Configuration file used by the JSON manager project.---

## Repository Structure

```text
aiml-crash-yash/
│
├── Jupyter Notebooks
├── Python Scripts
├── CSV Files
├── JSON Files
└── README.md
```

---

## How to Run

### Prerequisites

Make sure the following are installed:

* Python 3.x
* Jupyter Notebook
* Pandas
* NumPy

### Install Required Libraries

```bash
pip install pandas numpy jupyter
```

### Clone the Repository

```bash
git clone <repository-link>
```

### Navigate to the Project Directory

```bash
cd aiml-crash-yash
```

### Run Python Scripts

```bash
python filename.py
```

Example:

```bash
python student_report.py
```

```bash
python task8_numpy_basics.py
```

### Run Jupyter Notebooks

Start Jupyter Notebook:

```bash
jupyter notebook
```

Then open and run any notebook file such as:

* intro.ipynb
* calculator.ipynb
* grade_classifier.ipynb
* contact_book.ipynb

### Run JSON-Based Tasks

Ensure that `data.json` is located in the same directory as `task2_json_report.py`.

```bash
python task2_json_report.py
```

### Run Pandas Tasks

```bash
python task4_filter_dataframe.py
python task5_loc_iloc.py
python task6_missing_values.py
python task7_insights.py
```

### Run NumPy Tasks

```bash
python task8_numpy_basics.py
python task9_numpy_advanced.py
```

---

## Learning Outcomes

Through these projects, I gained practical experience in:

* Writing clean and reusable Python code
* Working with functions and modular programming
* Implementing Object-Oriented Programming concepts
* Reading and writing CSV and JSON files
* Managing and analyzing datasets using Pandas
* Cleaning and filtering data
* Creating and manipulating NumPy arrays
* Applying vector mathematics and similarity calculations
* Building small real-world applications
* Using Git and GitHub for project management

---

## Future Goals

* Machine Learning Projects
* Data Visualization with Matplotlib and Seaborn
* Flask and Streamlit Applications
* Database Integration (MySQL & MongoDB)
* Deep Learning using TensorFlow and PyTorch
* End-to-End AI/ML Projects

---

## Author

**Yash Dadhich**

Aspiring AI & Machine Learning Engineer

* Python Developer
* Data Science Enthusiast
* AI/ML Learner
* Open Source Contributor

---

## Acknowledgements

This repository represents my continuous learning journey in Python, Data Analysis, and Artificial Intelligence. Each project contributes to building a stronger foundation for future software development and AI/ML applications.
